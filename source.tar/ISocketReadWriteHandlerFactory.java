public interface ISocketReadWriteHandlerFactory {
    public IReadWriteHandler createHandler();
}