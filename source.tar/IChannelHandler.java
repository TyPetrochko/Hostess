public interface IChannelHandler {
    public void handleException();
}