// A wrapper for storing a virtual host 

class VirtualHost{
	public String documentRoot = "./";
	public String serverName = "";
}